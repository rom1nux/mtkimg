var searchData=
[
  ['default_5fcompress_5frate',['DEFAULT_COMPRESS_RATE',['../main_8h.html#a67ece6aafbb2ea9606195856761dd595',1,'main.h']]],
  ['default_5fconfig_5ffilename',['DEFAULT_CONFIG_FILENAME',['../main_8h.html#a2a97e742f32ed43aed0b56831f084eea',1,'main.h']]],
  ['default_5fimg_5ffilename',['DEFAULT_IMG_FILENAME',['../main_8h.html#a9e2f4a86ca3c2cc1dbf051433f49eae0',1,'main.h']]],
  ['default_5fkernel_5ffilename',['DEFAULT_KERNEL_FILENAME',['../main_8h.html#a12871b68ab9a1d74d83b16a481a30bc8',1,'main.h']]],
  ['default_5fkernel_5fmtk_5ffilename',['DEFAULT_KERNEL_MTK_FILENAME',['../main_8h.html#a7efef6b049db19ceced8e9bc36a61f70',1,'main.h']]],
  ['default_5framdisk_5fdir',['DEFAULT_RAMDISK_DIR',['../main_8h.html#a59a6a5600d89f39aa546a6da4de69fd0',1,'main.h']]],
  ['default_5framdisk_5ffilename',['DEFAULT_RAMDISK_FILENAME',['../main_8h.html#a3e07d68d7fa9f60498729949df9f0e56',1,'main.h']]],
  ['default_5framdisk_5fmtk_5ffilename',['DEFAULT_RAMDISK_MTK_FILENAME',['../main_8h.html#a0737fe5fb535b796cc64fd0f6d62a6f8',1,'main.h']]],
  ['dir_5fchmod',['DIR_CHMOD',['../main_8h.html#a02812b5f7c32e84a3f79bd374a7a09ed',1,'main.h']]]
];
