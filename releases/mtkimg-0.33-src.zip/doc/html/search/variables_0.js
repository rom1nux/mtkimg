var searchData=
[
  ['app_5fdata',['app_data',['../main_8h.html#ad474137910a57d22edcae4fbd5b17a0d',1,'main.h']]],
  ['argc',['argc',['../structargs__t.html#ad1447518f4372828b8435ae82e48499e',1,'args_t']]],
  ['argv',['argv',['../structargs__t.html#af2efa898e9eed6fe6715279cb1ec35b0',1,'args_t']]]
];
