var searchData=
[
  ['bool',['bool',['../main_8h.html#abb452686968e48b67397da5f97445f5b',1,'main.h']]],
  ['bool2yn',['bool2yn',['../main_8h.html#a4e3de9d1f4cd6783348ea0cd0e815d25',1,'main.h']]],
  ['buffer_5fsize',['BUFFER_SIZE',['../main_8h.html#a6b20d41d6252e9871430c242cb1a56e7',1,'main.h']]]
];
