var searchData=
[
  ['tags_5faddr',['tags_addr',['../structimg__header__t.html#a79bc4044043abf4e87c8ced5ea4db847',1,'img_header_t']]],
  ['type',['type',['../structmtk__header__t.html#a9acf1fefc6ac2287c48bfac44b8f3b81',1,'mtk_header_t::type()'],['../structimg__cfg__t.html#a9acf1fefc6ac2287c48bfac44b8f3b81',1,'img_cfg_t::type()']]]
];
