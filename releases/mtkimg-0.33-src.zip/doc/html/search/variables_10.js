var searchData=
[
  ['working_5fdir',['working_dir',['../structapp__data__t.html#af5703d73f10e2c279d3a9f2a08f4485e',1,'app_data_t']]]
];
