var searchData=
[
  ['debug',['debug',['../structapp__data__t.html#a398527b3e9e358c345c5047b16871957',1,'app_data_t::debug()'],['../tools_8c.html#a30654c55dca96c720074d096a749999a',1,'debug(const char *fmt,...):&#160;tools.c'],['../tools_8h.html#a30654c55dca96c720074d096a749999a',1,'debug(const char *fmt,...):&#160;tools.c']]],
  ['default_5fcompress_5frate',['DEFAULT_COMPRESS_RATE',['../main_8h.html#a67ece6aafbb2ea9606195856761dd595',1,'main.h']]],
  ['default_5fconfig_5ffilename',['DEFAULT_CONFIG_FILENAME',['../main_8h.html#a2a97e742f32ed43aed0b56831f084eea',1,'main.h']]],
  ['default_5fimg_5ffilename',['DEFAULT_IMG_FILENAME',['../main_8h.html#a9e2f4a86ca3c2cc1dbf051433f49eae0',1,'main.h']]],
  ['default_5fkernel_5ffilename',['DEFAULT_KERNEL_FILENAME',['../main_8h.html#a12871b68ab9a1d74d83b16a481a30bc8',1,'main.h']]],
  ['default_5fkernel_5fmtk_5ffilename',['DEFAULT_KERNEL_MTK_FILENAME',['../main_8h.html#a7efef6b049db19ceced8e9bc36a61f70',1,'main.h']]],
  ['default_5framdisk_5fdir',['DEFAULT_RAMDISK_DIR',['../main_8h.html#a59a6a5600d89f39aa546a6da4de69fd0',1,'main.h']]],
  ['default_5framdisk_5ffilename',['DEFAULT_RAMDISK_FILENAME',['../main_8h.html#a3e07d68d7fa9f60498729949df9f0e56',1,'main.h']]],
  ['default_5framdisk_5fmtk_5ffilename',['DEFAULT_RAMDISK_MTK_FILENAME',['../main_8h.html#a0737fe5fb535b796cc64fd0f6d62a6f8',1,'main.h']]],
  ['die',['die',['../tools_8c.html#a359a5ab470fcf838d04893f5b115e78a',1,'die(const char *fmt,...):&#160;tools.c'],['../tools_8h.html#a359a5ab470fcf838d04893f5b115e78a',1,'die(const char *fmt,...):&#160;tools.c']]],
  ['dir_5fchange',['dir_change',['../tools_8c.html#a563e63c1c5138412b89704a9d7239363',1,'dir_change(char *dirname):&#160;tools.c'],['../tools_8h.html#a563e63c1c5138412b89704a9d7239363',1,'dir_change(char *dirname):&#160;tools.c']]],
  ['dir_5fchmod',['DIR_CHMOD',['../main_8h.html#a02812b5f7c32e84a3f79bd374a7a09ed',1,'main.h']]],
  ['dir_5fcreate',['dir_create',['../tools_8c.html#aea8951fee77e769a5453f2ca5252fe0f',1,'dir_create(char *dirname):&#160;tools.c'],['../tools_8h.html#aea8951fee77e769a5453f2ca5252fe0f',1,'dir_create(char *dirname):&#160;tools.c']]],
  ['dir_5fexists',['dir_exists',['../tools_8c.html#a45ce2eae0edaff2ef1bdc882a37e687a',1,'dir_exists(char *dirname):&#160;tools.c'],['../tools_8h.html#a45ce2eae0edaff2ef1bdc882a37e687a',1,'dir_exists(char *dirname):&#160;tools.c']]],
  ['dir_5fget_5fcurrent',['dir_get_current',['../tools_8c.html#a85a2f5ba0007ba0887e0049c3ce86a73',1,'dir_get_current(char *dirname):&#160;tools.c'],['../tools_8h.html#a85a2f5ba0007ba0887e0049c3ce86a73',1,'dir_get_current(char *dirname):&#160;tools.c']]],
  ['dir_5fremove',['dir_remove',['../tools_8c.html#a5aa643a3ebdbb3d7ac25e2e562965882',1,'dir_remove(char *dirname):&#160;tools.c'],['../tools_8h.html#a5aa643a3ebdbb3d7ac25e2e562965882',1,'dir_remove(char *dirname):&#160;tools.c']]]
];
