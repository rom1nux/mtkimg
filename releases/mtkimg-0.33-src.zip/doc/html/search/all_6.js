var searchData=
[
  ['gzip_5fbin',['GZIP_BIN',['../main_8h.html#a779f6e839309b3ddc52963ba8283319b',1,'main.h']]]
];
