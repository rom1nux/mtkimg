var searchData=
[
  ['id',['id',['../structimg__header__t.html#a6e7259ef8bc488d2384e6896cef579d6',1,'img_header_t']]],
  ['input',['input',['../structinfo__data__t.html#acd629882404ffe96c85d356b0eb4090d',1,'info_data_t::input()'],['../structunpack__data__t.html#acd629882404ffe96c85d356b0eb4090d',1,'unpack_data_t::input()']]]
];
