var searchData=
[
  ['app_5farch',['APP_ARCH',['../main_8h.html#a0f79edc628fc148c9ac2a0607f02920f',1,'main.h']]],
  ['app_5fauthor',['APP_AUTHOR',['../main_8h.html#a87832488ddb61266f75ab21e1b6402cb',1,'main.h']]],
  ['app_5fdata',['app_data',['../main_8h.html#ad474137910a57d22edcae4fbd5b17a0d',1,'main.h']]],
  ['app_5fdata_5ft',['app_data_t',['../structapp__data__t.html',1,'app_data_t'],['../main_8h.html#ae632651387aca056132e177306de9af5',1,'app_data_t():&#160;main.h']]],
  ['app_5fname',['APP_NAME',['../main_8h.html#af0b5cfa4242ae7f98ba80fd23ef8afa9',1,'main.h']]],
  ['app_5ftitle',['APP_TITLE',['../main_8h.html#abce3c9120e09e75fd797f72f1b4a4cfb',1,'main.h']]],
  ['app_5fversion',['APP_VERSION',['../main_8h.html#a92673e33f27532767749b79edb8ef806',1,'main.h']]],
  ['argc',['argc',['../structargs__t.html#ad1447518f4372828b8435ae82e48499e',1,'args_t']]],
  ['args_5fadd',['args_add',['../tools_8c.html#a2ef7b372c1a8b507feeadac3fee9bac7',1,'args_add(args_t *args, char *arg):&#160;tools.c'],['../tools_8h.html#a2ef7b372c1a8b507feeadac3fee9bac7',1,'args_add(args_t *args, char *arg):&#160;tools.c']]],
  ['args_5fdebug',['args_debug',['../tools_8c.html#abf159a0d699564797b3ff38e9870f5a0',1,'args_debug(args_t *args):&#160;tools.c'],['../tools_8h.html#abf159a0d699564797b3ff38e9870f5a0',1,'args_debug(args_t *args):&#160;tools.c']]],
  ['args_5ffree',['args_free',['../tools_8c.html#a24eceec5dfec53989d435de16dd0c832',1,'args_free(args_t *args):&#160;tools.c'],['../tools_8h.html#a24eceec5dfec53989d435de16dd0c832',1,'args_free(args_t *args):&#160;tools.c']]],
  ['args_5finit',['args_init',['../tools_8c.html#a897d6d7a4c007139b4a7ba970ba41ba7',1,'args_init(args_t *args):&#160;tools.c'],['../tools_8h.html#a897d6d7a4c007139b4a7ba970ba41ba7',1,'args_init(args_t *args):&#160;tools.c']]],
  ['args_5ft',['args_t',['../structargs__t.html',1,'args_t'],['../main_8h.html#a3e4e4434394af00b6501b60acfe570c0',1,'args_t():&#160;main.h']]],
  ['argv',['argv',['../structargs__t.html#af2efa898e9eed6fe6715279cb1ec35b0',1,'args_t']]]
];
