var searchData=
[
  ['path_5fmax_5fsize',['PATH_MAX_SIZE',['../main_8h.html#a965df5ba2db3f4ad3d1875ce90992b74',1,'main.h']]]
];
