var searchData=
[
  ['no_5fcompress',['no_compress',['../structrepack__data__t.html#a025857c19ece5323b31b41dff6d870d9',1,'repack_data_t']]],
  ['no_5fdecompress',['no_decompress',['../structunpack__data__t.html#a63936c0bec3f69261d6b8a07492a8dbf',1,'unpack_data_t']]]
];
