var searchData=
[
  ['app_5fdata_5ft',['app_data_t',['../main_8h.html#ae632651387aca056132e177306de9af5',1,'main.h']]],
  ['args_5ft',['args_t',['../main_8h.html#a3e4e4434394af00b6501b60acfe570c0',1,'main.h']]]
];
