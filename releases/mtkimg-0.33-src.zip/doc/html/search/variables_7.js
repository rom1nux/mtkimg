var searchData=
[
  ['magic',['magic',['../structmtk__header__t.html#ad7cd56f245d5dbca367259b8695c3c6e',1,'mtk_header_t']]]
];
