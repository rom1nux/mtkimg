var searchData=
[
  ['ramdisk',['ramdisk',['../structrepack__data__t.html#ab7aad48ae23d02c540a5b4b03fd93ae2',1,'repack_data_t::ramdisk()'],['../structunpack__data__t.html#ab7aad48ae23d02c540a5b4b03fd93ae2',1,'unpack_data_t::ramdisk()']]],
  ['ramdisk_5fload_5faddr',['ramdisk_load_addr',['../structimg__header__t.html#a499a636d133db16b69450ea7502dd6cb',1,'img_header_t']]],
  ['ramdisk_5fsize',['ramdisk_size',['../structimg__header__t.html#af2c640e99f79fac40e17a3a55a70797f',1,'img_header_t']]]
];
