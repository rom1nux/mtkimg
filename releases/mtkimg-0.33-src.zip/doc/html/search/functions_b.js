var searchData=
[
  ['verbose',['verbose',['../tools_8c.html#a79ae98299946ec9fcc50fdafb8c044ef',1,'verbose(const char *fmt,...):&#160;tools.c'],['../tools_8h.html#a79ae98299946ec9fcc50fdafb8c044ef',1,'verbose(const char *fmt,...):&#160;tools.c']]]
];
