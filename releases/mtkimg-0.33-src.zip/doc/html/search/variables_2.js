var searchData=
[
  ['debug',['debug',['../structapp__data__t.html#a398527b3e9e358c345c5047b16871957',1,'app_data_t']]]
];
