var searchData=
[
  ['warning',['warning',['../tools_8c.html#a1a684a7bdfd73a0b441960754ba5f286',1,'warning(const char *fmt,...):&#160;tools.c'],['../tools_8h.html#a1a684a7bdfd73a0b441960754ba5f286',1,'warning(const char *fmt,...):&#160;tools.c']]],
  ['working_5fdir',['working_dir',['../structapp__data__t.html#af5703d73f10e2c279d3a9f2a08f4485e',1,'app_data_t']]]
];
