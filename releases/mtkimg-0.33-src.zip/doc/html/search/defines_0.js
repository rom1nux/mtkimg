var searchData=
[
  ['app_5farch',['APP_ARCH',['../main_8h.html#a0f79edc628fc148c9ac2a0607f02920f',1,'main.h']]],
  ['app_5fauthor',['APP_AUTHOR',['../main_8h.html#a87832488ddb61266f75ab21e1b6402cb',1,'main.h']]],
  ['app_5fname',['APP_NAME',['../main_8h.html#af0b5cfa4242ae7f98ba80fd23ef8afa9',1,'main.h']]],
  ['app_5ftitle',['APP_TITLE',['../main_8h.html#abce3c9120e09e75fd797f72f1b4a4cfb',1,'main.h']]],
  ['app_5fversion',['APP_VERSION',['../main_8h.html#a92673e33f27532767749b79edb8ef806',1,'main.h']]]
];
