var searchData=
[
  ['tags_5faddr',['tags_addr',['../structimg__header__t.html#a79bc4044043abf4e87c8ced5ea4db847',1,'img_header_t']]],
  ['tmp_5framdisk_5ffilename',['TMP_RAMDISK_FILENAME',['../main_8h.html#af05732fdfe566f43ab9a7d20fe6578a7',1,'main.h']]],
  ['tools_2ec',['tools.c',['../tools_8c.html',1,'']]],
  ['tools_2eh',['tools.h',['../tools_8h.html',1,'']]],
  ['true',['true',['../main_8h.html#a41f9c5fb8b08eb5dc3edce4dcb37fee7',1,'main.h']]],
  ['type',['type',['../structmtk__header__t.html#a9acf1fefc6ac2287c48bfac44b8f3b81',1,'mtk_header_t::type()'],['../structimg__cfg__t.html#a9acf1fefc6ac2287c48bfac44b8f3b81',1,'img_cfg_t::type()']]]
];
