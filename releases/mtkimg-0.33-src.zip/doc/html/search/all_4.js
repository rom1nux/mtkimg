var searchData=
[
  ['error',['error',['../tools_8c.html#ac33c8a42a58a6379397850b60be22028',1,'error(const char *fmt,...):&#160;tools.c'],['../tools_8h.html#ac33c8a42a58a6379397850b60be22028',1,'error(const char *fmt,...):&#160;tools.c']]],
  ['exename',['exename',['../structapp__data__t.html#a3b220e16914b029b3755dc41339c8ffe',1,'app_data_t']]]
];
