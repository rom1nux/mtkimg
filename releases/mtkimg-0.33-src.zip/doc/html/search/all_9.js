var searchData=
[
  ['keep_5fmtk_5fheader',['keep_mtk_header',['../structunpack__data__t.html#a1e38425a8f82857901ba0fa3513ae62f',1,'unpack_data_t']]],
  ['kernel',['kernel',['../structrepack__data__t.html#a08d3b85024c4f713ef72ce39bc05fba1',1,'repack_data_t::kernel()'],['../structunpack__data__t.html#a08d3b85024c4f713ef72ce39bc05fba1',1,'unpack_data_t::kernel()']]],
  ['kernel_5fload_5faddr',['kernel_load_addr',['../structimg__header__t.html#a81b648a7f4c294356062fca8d7ffe222',1,'img_header_t']]],
  ['kernel_5fsize',['kernel_size',['../structimg__header__t.html#a778723b1bdcbb58a3118d099c7df676b',1,'img_header_t']]]
];
