var searchData=
[
  ['app_5fdata_5ft',['app_data_t',['../structapp__data__t.html',1,'']]],
  ['args_5ft',['args_t',['../structargs__t.html',1,'']]]
];
