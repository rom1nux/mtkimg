var searchData=
[
  ['str_5fmax_5fsize',['STR_MAX_SIZE',['../main_8h.html#a4a5ae9e2ea352380175b1aec9a5d6d1b',1,'main.h']]]
];
