var searchData=
[
  ['verbose',['verbose',['../structapp__data__t.html#ab3f078684998b83967d507d0f453f454',1,'app_data_t']]]
];
